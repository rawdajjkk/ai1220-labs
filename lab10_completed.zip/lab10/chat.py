"""Terminal chat with the study-room desk assistant.

Run with:  uv run --env-file lmstudio.env python chat.py
           uv run --env-file ifm.env python chat.py
"""
import os
import uuid

from pydantic_ai import Agent
from pydantic_ai.exceptions import AgentRunError
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider


SYSTEM_INSTRUCTIONS = (
    "You are the assistant at a library study-room desk. Answer questions about "
    "studying and study rooms helpfully and accurately, in at most three sentences."
)

model = OpenAIChatModel(
    os.environ["LLM_MODEL"],
    provider=OpenAIProvider(
        base_url=os.environ["LLM_BASE_URL"],
        api_key=os.environ["LLM_API_KEY"],
    ),
)
agent = Agent(model, instructions=SYSTEM_INSTRUCTIONS)


def main() -> None:
    """Run the terminal conversation until /quit or end of input."""
    print("Study-room desk. Type /new for a new conversation and /quit to leave.")
    message_history = None
    session_id = uuid.uuid4().hex

    while True:
        try:
            prompt = input("you> ")
        except EOFError:
            break

        if not prompt.strip():
            continue
        if prompt == "/quit":
            break
        if prompt == "/new":
            message_history = None
            session_id = uuid.uuid4().hex
            print("New conversation.")
            continue

        try:
            result = agent.run_sync(
                prompt,
                message_history=message_history,
                model_settings={"extra_headers": {"X-Session-ID": session_id}},
            )
        except AgentRunError as exc:
            print(f"desk> Error: {exc}")
            continue

        # Commit history only after a successful model run; failed prompts are not
        # included in the next request.
        message_history = result.all_messages()
        print(f"desk> {result.output}")


if __name__ == "__main__":
    main()
