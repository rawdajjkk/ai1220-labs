# CampusPulse requirements review

Name or team: Rawda Alkhoori

Reviewer: Rawda Alkhoori

Date: 8 September 2026

Review the completed `stakeholders.md` and `REQUIREMENTS.md`. Refer to specific
IDs and evidence in every answer. A yes or no by itself is not enough.

## Validity

Do the requirements represent what the stakeholders need? Which IDs did you
check, and what evidence supports them?

Response:

The requirements represent the main stakeholder needs. UR-2 and FR-2 reflect S1's request that RSVP names should not be public unless the student chooses and S5's requirement that RSVP lists start private. UR-3 and FR-3 reflect S2's requirement that only approved officers publish. UR-5 and FR-6 reflect S3's need to hide an event while preserving evidence and recording the moderation decision. UR-6 and FR-7 reflect S4's requirement that an official badge only means Student Affairs has checked the group.

## Consistency

Do any requirements contradict one another or the release scope?

Response:

No direct contradictions were found. The Out of Scope section excludes native mobile apps, direct messages, external users, payments, video hosting, and AI recommendations, and the Won't list contains the same exclusions. UR-2 and FR-2 are also consistent with the privacy requirement because RSVP visibility is private by default while still allowing the student to explicitly choose public visibility.

## Completeness

Is an important actor, normal flow, failure, permission, privacy rule, or
boundary missing?

Response:

The specification includes the main actors: students, group officers, moderators, Student Affairs, the Data Protection Officer, and abusive users. It includes normal flows such as following, RSVP, publishing, and event updates. It also includes permission failure in FR-3 and US-2, privacy rules in FR-2 and NFR-3, and moderation and appeal behaviour in FR-6 and FR-10. However, the source notes do not provide a peak traffic figure for Orientation Week, so this remains open question Q1 rather than an invented requirement.

## Realism

Can the proposed release and its quality targets reasonably be delivered? Mark
unsupported targets as assumptions or open questions.

Response:

The release scope is limited because native mobile apps, direct messages, payments, video hosting, external users, and AI recommendations are excluded. The stakeholder-provided capacity target of 5,000 students and 200 groups is represented by UR-9 and NFR-1. The WCAG 2.2 AA target in NFR-2 is recorded as assumption A1 because the stakeholder only specified screen-reader support. The 95% within 2 minutes target in NFR-4 is recorded as assumption A2 because no notification-performance number was provided. Orientation Week peak traffic is still open question Q1.

## Verifiability

Could a tester decide whether each requirement passes or fails? Identify any
wording that is still vague.

Response:

Most requirements are testable because they describe observable actions or measurable results. For example, FR-3 can be tested by attempting publication with approved and non-approved accounts. FR-7 can be tested using verified and unverified groups. NFR-1 specifies the pilot size and NFR-3 specifies the 30-day deletion period. FR-6 originally only said that moderators could hide an event, which was not enough to test the evidence and audit requirements from S3, so FR-6 was revised.

## One requirement you revised

- Requirement ID: FR-6
- Before: The system shall allow a moderator to hide a reported event.
- What was wrong or missing: The wording only described hiding the event. It did not state that the report reason and evidence must be preserved or that the person making the moderation decision must be recorded, even though S3 requires those details for appeals.
- After: The system shall record the reported event and report reason, allow an authorised moderator to hide the event immediately, and preserve the evidence together with who made the moderation decision for use during an appeal. [Source: UR-5]
- Evidence or stakeholder to confirm the change: S3, Campus moderator.

## Final check

- [x] Stakeholder conflicts have a decision or a follow-up question.
- [x] Scope exclusions agree with the Won't list.
- [x] Every FR and NFR traces to a user requirement.
- [x] Every NFR contains a measurable target and condition.
- [x] Traceability rows use IDs that exist in the document.
- [x] The revised requirement has also been updated in the traceability table.
