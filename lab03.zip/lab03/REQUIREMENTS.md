# CampusPulse requirements

Name or team: Rawda Alkhoori

Date: 8 September 2026

Status: working draft

Use the source IDs `S1` to `S6` from the lab handout. Keep every requirement
short enough to test and trace.

## 1. Release scope

### In scope

- University sign-in and verified university groups.
- Group announcements and campus events.
- Following groups and viewing their updates.
- RSVP with private-by-default attendance visibility.
- University-wide and members-only event audiences.
- Notifications when an RSVP'd event's time or location changes.
- Reports, moderation, evidence retention, and appeals.
- Official badges for groups checked by Student Affairs.

### Out of scope

- Native mobile application.
- Direct messages.
- External users.
- Payments.
- Video hosting.
- AI recommendations.

## 2. User requirements

- UR-1 [Must] Students can follow verified groups and see their announcements and events in one browser-based service. [Source: S1]
- UR-2 [Must] Students can RSVP to events without their names appearing publicly unless they choose public visibility. [Source: S1, S5]
- UR-3 [Must] Only approved group officers can publish announcements and events. [Source: S2]
- UR-4 [Must] Group officers can choose whether an event is university-wide or members-only, and people who RSVP are informed when its time or location changes. [Source: S2]
- UR-5 [Must] Students can report suspicious events with a reason, and moderators can act on the report while preserving evidence and the decision record. [Source: S3, S6]
- UR-6 [Must] An official badge is displayed only for a group that Student Affairs has checked. [Source: S4, S6]
- UR-7 [Must] Attendance data for a cancelled event is deleted within 30 days. [Source: S5]
- UR-8 [Must] Core student functions are accessible to students who use screen readers. [Source: S1]
- UR-9 [Must] The CampusPulse pilot supports 5,000 students and 200 groups before Orientation Week. [Source: S4]
- UR-10 [Could] One approved group officer can continue editing an unpublished announcement started by another approved officer. [Source: S2]
- UR-11 [Must] A group can appeal a moderation decision and the preserved evidence can be reviewed during the appeal. [Source: S3]

## 3. Functional requirements

- FR-1 [Must] The system shall allow an authenticated student to follow a verified group and view announcements and events from that group. [Source: UR-1]
- FR-2 [Must] The system shall record an RSVP with the student's name private by default and shall display the name publicly only after the student explicitly chooses public visibility. [Source: UR-2]
- FR-3 [Must] The system shall allow only approved group officers to publish announcements and events and shall reject publication attempts from users without that permission. [Source: UR-3]
- FR-4 [Must] The system shall allow an approved officer to set an event audience as university-wide or members-only and shall restrict access according to that setting. [Source: UR-4]
- FR-5 [Must] The system shall notify users who RSVP'd when an event's time or location is changed. [Source: UR-4]
- FR-6 [Must] The system shall record the reported event and report reason, allow an authorised moderator to hide the event immediately, and preserve the evidence together with who made the moderation decision for use during an appeal. [Source: UR-5]
- FR-7 [Must] The system shall display an official badge only when the group has been verified by Student Affairs. [Source: UR-6]
- FR-8 [Must] The system shall delete attendance data associated with a cancelled event no later than 30 days after cancellation. [Source: UR-7]
- FR-9 [Could] The system shall allow an approved officer to edit an unpublished announcement draft created by another approved officer. [Source: UR-10]
- FR-10 [Must] The system shall allow an appeal to be recorded for a hidden event and make its retained moderation evidence available for review during the appeal. [Source: UR-11]

## 4. Non-functional requirements

- NFR-1 [Must] The system shall support the planned pilot population. [Measure: data for at least 5,000 student accounts and 200 groups can be stored and retrieved successfully in the pre-release pilot test environment] [Source: UR-9]
- NFR-2 [Must] The system shall make core student pages accessible to screen-reader users. [Measure: all core student flows pass the agreed WCAG 2.2 AA accessibility review before release] [Source: UR-8]
- NFR-3 [Must] The system shall remove cancelled-event attendance data within the required retention period. [Measure: 100% of attendance records associated with a cancelled event are deleted no later than 30 days after cancellation] [Source: UR-7]
- NFR-4 [Should] The system shall deliver event correction notifications promptly. [Measure: at least 95% of notifications about event time or location changes are delivered within 2 minutes in the agreed pilot load-test environment] [Source: UR-4]

## 5. User stories and acceptance criteria

### US-1 [Source: S1, S5, UR-2]

As a student attendee,

I want my RSVP to be private unless I choose otherwise,

so that I can attend campus events without automatically publishing my attendance.

Acceptance criteria:

- When a student submits a new RSVP, the student's name is not shown on a public attendee list by default.
- When the student explicitly selects public visibility, the student's name may appear publicly; when private visibility is selected, it does not appear publicly.

### US-2 [Source: S2, UR-3, UR-10]

As a group officer,

I want approved officers to work on announcements while publication remains permission-controlled,

so that our group can collaborate without unauthorised people publishing content.

Acceptance criteria:

- An approved officer can edit an unpublished draft started by another approved officer.
- When a user who is not an approved officer attempts to publish, the publication is rejected and the content remains unpublished.

### US-3 [Source: S3, UR-5, UR-11]

As a campus moderator,

I want to hide a suspicious event while keeping its evidence and decision record,

so that I can protect users immediately and still support an appeal.

Acceptance criteria:

- A report records the reported event and the reason for the report, and an authorised moderator can hide the event.
- After the event is hidden, normal users cannot view it, but its evidence and moderation decision remain available during an appeal.

### US-4 [Source: S4, S6, UR-6]

As Student Affairs,

I want official badges to appear only on groups we have checked,

so that students can distinguish verified groups from impersonators.

Acceptance criteria:

- A group that has not been verified by Student Affairs does not display an official badge.
- A group that has been verified by Student Affairs displays the official badge.

## 6. MoSCoW summary

- Must: UR-1, UR-2, UR-3, UR-4, UR-5, UR-6, UR-7, UR-8, UR-9, UR-11, FR-1, FR-2, FR-3, FR-4, FR-5, FR-6, FR-7, FR-8, FR-10, NFR-1, NFR-2, NFR-3
- Should: NFR-4
- Could: UR-10, FR-9
- Won't this release: Native mobile app, direct messages, external users, payments, video hosting, and AI recommendations.

## 7. Traceability

| Stakeholder need | User requirement | System requirement | User story |
|---|---|---|---|
| S1/S5: RSVP attendance should be private by default | UR-2 | FR-2 | US-1 |
| S2: Only approved officers should publish | UR-3 | FR-3 | US-2 |
| S3: Moderators must hide harmful content while preserving evidence for appeals | UR-5, UR-11 | FR-6, FR-10 | US-3 |
| S4/S6: Official badges must identify checked groups and reduce impersonation risk | UR-6 | FR-7 | US-4 |
| S2: Another approved officer may finish a draft | UR-10 | FR-9 | US-2 |

## 8. Assumptions and open questions

### Assumptions

- A1: WCAG 2.2 AA will be used as the accessibility acceptance target for core student flows because the source notes require screen-reader support but do not specify an accessibility standard.
- A2: For testing, at least 95% of event-change notifications should arrive within 2 minutes. This performance target was not supplied by a stakeholder and must be confirmed.

### Open questions

- Q1: What peak concurrent-user or request volume should be used for Orientation Week performance testing?
- Q2: Which notification channels should be used for event corrections: in-app notifications, university email, or both?
- Q3: How long should moderation evidence and decision records be retained after an appeal is completed?
