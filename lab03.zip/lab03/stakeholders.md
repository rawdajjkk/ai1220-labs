# CampusPulse stakeholder analysis

Name or team: Rawda Alkhoori

Date: 8 September 2026

Read the stakeholder notes in the lab handout before completing this file.
Use the stakeholder types and power-interest quadrants from Week 2, Lecture 2.

Stakeholder types: end user, operations, business, regulator, negative stakeholder

Power-interest quadrants: key player, keep satisfied, keep informed, minimal effort

## S1

- Stakeholder: Student attendee
- Stakeholder type: end user
- Power-interest quadrant: keep informed
- Main goal: Follow university groups and find their events and announcements in one place.
- Main concern: RSVP privacy and accessibility for students who use screen readers.
- How you would involve or monitor this stakeholder: Ask students to test the event feed, RSVP privacy settings, and screen-reader accessibility, then collect feedback during the pilot.

## S2

- Stakeholder: Group officer
- Stakeholder type: end user
- Power-interest quadrant: key player
- Main goal: Create, edit, and publish announcements and events for the correct audience.
- Main concern: Only approved officers should publish, while approved officers should still be able to collaborate on drafts.
- How you would involve or monitor this stakeholder: Include group officers in prototype testing for publishing, permissions, audience settings, and event updates.

## S3

- Stakeholder: Campus moderator
- Stakeholder type: operations
- Power-interest quadrant: key player
- Main goal: Respond quickly to harmful or suspicious content while keeping enough evidence for appeals.
- Main concern: Reports must show what was reported and why, hidden content must retain evidence, and moderation decisions must identify who made them.
- How you would involve or monitor this stakeholder: Test reporting, hiding, evidence retention, decision records, and appeals with campus moderators before release.

## S4

- Stakeholder: Student Affairs
- Stakeholder type: business
- Power-interest quadrant: key player
- Main goal: Launch a trusted pilot for 5,000 students and 200 groups before Orientation Week.
- Main concern: The official badge must only be shown for groups that Student Affairs has checked.
- How you would involve or monitor this stakeholder: Review scope, verification rules, capacity, and release readiness regularly with Student Affairs.

## S5

- Stakeholder: Data Protection Officer
- Stakeholder type: regulator
- Power-interest quadrant: keep satisfied
- Main goal: Make sure CampusPulse collects and keeps only the personal data it needs.
- Main concern: RSVP lists must start private, and attendance data for cancelled events must be deleted within 30 days.
- How you would involve or monitor this stakeholder: Ask the Data Protection Officer to review privacy settings, data collection, and retention rules before release.

## S6

- Stakeholder: Abusive user or attacker
- Stakeholder type: negative stakeholder
- Power-interest quadrant: minimal effort
- Main goal: Abuse the service by imitating verified groups, publishing phishing events, or repeatedly posting announcements from a compromised account.
- Main concern: These actions could damage trust and expose students to harmful content.
- How you would involve or monitor this stakeholder: Do not involve the attacker directly; monitor impersonation attempts, repeated posts, suspicious publishing behaviour, and user reports.

## Conflicts to resolve

### Conflict 1

- Stakeholders: S1 and S5
- What conflicts: S1 wants RSVP to be convenient, but S5 requires personal data to be minimized and RSVP lists to start private.
- Proposed decision or follow-up question: Keep RSVP names private by default and only show a student's name publicly after the student explicitly chooses public visibility.

### Conflict 2

- Stakeholders: S2 and S3
- What conflicts: S2 needs approved officers to publish and manage content, while S3 needs moderators to hide suspicious content immediately and still preserve evidence for appeals.
- Proposed decision or follow-up question: Allow moderators to hide an event immediately without deleting its report evidence or decision record, so the group can still appeal.
