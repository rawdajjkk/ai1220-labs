# Campus Workshop Board - Design notes

Name: Rawda Alkhoori  
Student ID: 25011159

Let the diagrams carry the explanation. Complete only these short notes.

## Diagram files

| View | Editable source (and page if needed) | Export |
|---|---|---|
| 01-context | `diagrams/source/01-context.dot` | `diagrams/exports/01-context.pdf` and `.svg` |
| 02-containers | `diagrams/source/02-containers.dot` | `diagrams/exports/02-containers.pdf` and `.svg` |
| 03-components | `diagrams/source/03-components.dot` | `diagrams/exports/03-components.pdf` and `.svg` |
| 04-code | `diagrams/source/04-code.dot` | `diagrams/exports/04-code.pdf` and `.svg` |
| 05-dynamic | `diagrams/source/05-dynamic.dot` | `diagrams/exports/05-dynamic.pdf` and `.svg` |

## One structural choice (Exercise 2)

One backend application and one relational database keep deployment and maintenance simple for a 200-student pilot and a small development team, while database transactions provide strong consistency for reservations.

## Your components (Exercise 3)

| Name | Job | Customer rule(s) served |
|---|---|---|
| Identity Adapter | Validates the signed-in university identity and supplies student ID, name and email to the application. | R1, R4 |
| Workshop Service | Creates workshops, enforces owner-only publishing, and provides published workshop details. | R2, R3 |
| Reservation Controller | Accepts reservation requests, coordinates the rule check, persistence and user-facing result. | R3, R4, R6 |
| Reservation Rules | Applies verification, duplicate-reservation, publication and capacity rules before/while reserving. | R4 |
| Workshop Query Service | Builds workshop listings including capacity, remaining seats and the current student's reservation; attendee details are organiser-only. | R3 |
| Persistence Adapter | Stores workshops, ownership and reservations durably and performs the atomic reservation transaction. | R4, R5 |
| Mail Adapter | Requests confirmation through University Mail and reports mail failure without undoing a saved seat. | R6 |

## Reservation operation (Exercise 4)

`reserve(student: StudentIdentity, workshopId: WorkshopId) -> ReserveResult`, where `ReserveResult` is one of `Created(Reservation)`, `Existing(Reservation)`, `Full`, `NotPublished`, or `Unverified`.

Invariant: for every workshop, stored reservations never exceed its capacity and each `(workshopId, studentId)` pair is unique. The Persistence Adapter performs the check-and-insert in one database transaction, locks the workshop row while capacity is checked, and has a unique constraint on `(workshop_id, student_id)`. Overlapping calls therefore serialize at the capacity check, while repeated calls return the existing reservation instead of inserting another row.

## Ari's incident (Exercise 5)

| Observation | Result |
|---|---|
| Stored state before | W17 (“Build a tiny game”) is published, owner S10, capacity 3; reservations exist for S21 and S22; Ari/S23 has no reservation. |
| Stored state after | W17 still has capacity 3 and now has reservations for S21, S22 and S23. Ari's seat remains stored even though mail failed. |
| Message Ari sees | **Reservation successful. Your seat is saved, but the confirmation email is currently unavailable.** |
