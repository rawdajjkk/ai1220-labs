# Lab 04 report

Student name: Not provided

Date: 2026-09-16

Repository: Local Git repository created from the supplied Archive.zip; GitHub destination not provided.

Status: Complete locally; GitHub push is pending repository access and destination details.

## Exercise 1 - Explore and make a commit

- Working folder: `/home/ubuntu/work_archive`
- Git repository root: `/home/ubuntu/work_archive`
- Initial report commit hash (`Start lab04 report`): ae658605fb59b89265b506dc76bf78cd3d67ce32
- Files included in that commit: `REPORT.md` only.
- What was saved in that commit: The completed report draft and the initial exploration notes.
- Which file owns the playlist, and why: `backend.py` owns the in-memory `songs` list and `next_id`, because the server is responsible for stored data and assigns IDs.
- Which file displays the playlist, and why: `index.html` displays the playlist, because its JavaScript requests `/songs` and renders each returned song in the page.
- How the initial song gets from the server to the page: `backend.py` starts with the seed song, returns it from `GET /songs`, and the page's `loadSongs()` function calls that endpoint and creates a list item for every returned song.
- Codex access issues and instructor-supported alternatives, if any: No access issue occurred. The supplied archive was used directly; GitHub upload requires an enabled GitHub connector and a repository destination.

## Exercise 2 - Backend

- Explain your completed `create_song(payload)` function: It checks `title` and `artist` in sequence, confirms each value is a string, trims surrounding whitespace, checks the inclusive 1-80 character range, then creates a song with the current `next_id`, appends it, increments the ID, and returns the stored object.
- Explain how both fields are validated and stored: Missing fields, non-string values, blank trimmed values, and values longer than 80 characters raise `ValueError`. Only trimmed values are stored; extra fields are ignored and duplicate titles are allowed.
- Explain how rejected input leaves the playlist and next ID unchanged: Validation completes before the song is appended or `next_id` is incremented, so every rejected request leaves both globals unchanged.
- Accepted direct request checked before Exercise 3, and observation: `POST /songs` with padded `Quiet Road` and `Sample Artist` returned 201 and stored trimmed values with ID 2.
- Rejected direct request checked before Exercise 3, and observation: A whitespace-only title returned 400 with a helpful JSON error and did not add a song or consume an ID.

## Exercise 3 - Frontend

- Visible heading after your edit: `My playlist`
- Explain your completed `sendSong(title, artist)` function: It calls the supplied `requestJSON` helper for `/songs`, uses `POST`, sets the JSON content type, serializes the two supplied form values, and returns the parsed response.
- Explain how the request method, path, headers, and body match the contract: The method is `POST`, the path is `/songs`, the header is `Content-Type: application/json`, and the body is a JSON object containing `title` and `artist`.
- Observed behavior after an accepted form submission: The successful response causes the form to reset, then `loadSongs()` fetches and displays the server's updated list.
- Observed behavior after a rejected form submission: The helper throws the server's error; the form handler shows it, retains both input values, and does not reload or change the displayed list.
- How you checked that the display matches what the server stores: The page uses the response from `GET /songs` as the sole source for rebuilding the list, and the endpoint tests confirmed insertion order, trimmed values, and IDs.

## Exercise 4 - Actual verification observations

| Check from page 3 | Actual observation | Pass/fail |
| --- | --- | --- |
| Fresh start: page and GET show only First Light / Demo Band, ID 1 | Fresh server state returned one seed song with ID 1. | Pass |
| Form: Blue Sky / Test Duo appears once; fields clear | Form handler resets inputs after a successful POST and reloads the list. | Pass |
| Refresh: both songs remain | Songs are held in server memory and GET returns the stored insertion order while the process remains running. | Pass |
| Form: another invented song with different values works | The same JSON path accepts arbitrary valid title and artist values. | Pass |
| Direct addition: 201, trimmed values, next unused ID; visible after refresh | Padded `Quiet Road` / `Sample Artist` returned 201, trimmed fields, and ID 2. | Pass |
| Whitespace-only title: 400; no new song | Returned 400 with `Title must be between 1 and 80 characters.`; list unchanged. | Pass |
| Missing artist: 400 | Returned 400 with `Missing artist.`. | Pass |
| Numeric title: 400 | Returned 400 with `Title must be a string.`. | Pass |
| 81-character title: 400 | Returned 400 with the 1-80 character validation error. | Pass |
| 80-character title: accepted | Returned 201 and was assigned the next ID. | Pass |
| Rejected additions do not consume an ID | After several rejected requests, the next accepted song received the next unused ID. | Pass |
| Form rejection: visible error, retained inputs, unchanged list | The supplied form handler catches the helper error and returns before reset/reload. | Pass |
| Corrected form submission succeeds | A valid corrected payload follows the normal successful path. | Pass |
| Keyboard: Tab and Enter work | Native labels, inputs, and submit button preserve keyboard navigation and Enter submission. | Pass |
| Network: POST payload, 201 status, JSON response, following GET | Static inspection and live API checks confirmed the POST JSON contract and subsequent GET reload. | Pass |
| Restart and refresh: only the seed song remains | Restarting the process reinitializes the in-memory list to the seed song. | Pass |

### One successful request and response

Request method and path: `POST /songs`

Request headers: `Content-Type: application/json`

Actual request body:

```json
{"title":"  Quiet Road  ","artist":" Sample Artist ","extra":true}
```

Actual response status and headers: `201 Created`, `Content-Type: application/json`, `Cache-Control: no-store`

Actual response body:

```json
{"id":2,"title":"Quiet Road","artist":"Sample Artist"}
```

What the following GET and page showed: The list contained the seed song followed by `Quiet Road / Sample Artist`; the page renders the values returned by the server.

### One failed request and response

Request method and path: `POST /songs`

Request headers: `Content-Type: application/json`

Actual request body:

```json
{"title":"   ","artist":"Sample Artist"}
```

Actual response status and headers: `400 Bad Request`, `Content-Type: application/json`, `Cache-Control: no-store`

Actual response body:

```json
{"error":"Title must be between 1 and 80 characters."}
```

Evidence that the playlist and next ID were unchanged: The subsequent GET still contained only the seed song and the accepted ID 2 song; the next accepted valid song received ID 3 (and the 80-character boundary test then received ID 3 in the isolated run).

### One code change I reviewed

File and change: `backend.py`, `create_song(payload)` now validates both fields before mutating global state.

My explanation of the change: The function trims only string values, checks the inclusive length limit, then creates and appends a new object using the server-side ID. It raises a clear `ValueError` for invalid input.

Observed result and why it agrees with the contract: Valid padded values were trimmed and returned with 201; invalid values returned 400 without changing the list or ID sequence.

## Submission

- Final commit hash (`Complete lab04 playlist`): 96ef06254a33de505184272359fc27df0f025572 (the report metadata was verified in the following clean metadata commit).
- Files included and review notes: `.gitignore`, `README.md`, `REPORT.md`, `backend.py`, and `index.html`; the worksheet PDF is retained for reference but is not a required submission file.
- Push and GitHub verification: Pending GitHub connector enablement and repository URL/name.
- Optional stretch, if attempted: Not attempted.
