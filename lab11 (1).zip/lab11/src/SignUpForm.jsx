import { useId, useState } from 'react';
import { checkName, checkMobile, checkEmail } from './validate.js';

function Field({ id, label, value, onChange, error, type = 'text', autoComplete }) {
  const errorId = `${id}-error`;
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <input
        id={id}
        type={type}
        autoComplete={autoComplete}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        aria-invalid={error ? 'true' : undefined}
        aria-describedby={error ? errorId : undefined}
      />
      {error && <p id={errorId} className="field-error">{error}</p>}
    </div>
  );
}

export default function SignUpForm() {
  const id = useId();
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState({ name: '', mobile: '', email: '' });
  const [created, setCreated] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    const found = { name: checkName(name), mobile: checkMobile(mobile), email: checkEmail(email) };
    setErrors(found);
    if (found.name || found.mobile || found.email) {
      setCreated('');
      return;
    }
    setCreated(`Account created for ${name.trim()}.`);
  }

  return (
    <form className="stack" onSubmit={handleSubmit} noValidate>
      <Field id={`${id}-name`} label="Full name" value={name} onChange={setName} error={errors.name} autoComplete="name" />
      <Field id={`${id}-mobile`} label="Mobile number" value={mobile} onChange={setMobile} error={errors.mobile} type="tel" autoComplete="tel" />
      <Field id={`${id}-email`} label="Email" value={email} onChange={setEmail} error={errors.email} type="email" autoComplete="email" />
      <button type="submit">Create account</button>
      <p className="result" role="status">{created}</p>
    </form>
  );
}
