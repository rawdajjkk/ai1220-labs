import { useState } from 'react';
import { INBOX } from './data.js';

export default function Inbox() {
  const [messages, setMessages] = useState(INBOX);
  const [lastDeleted, setLastDeleted] = useState(null);

  // Position of each message in the original list, used to put it back in its place.
  const order = (message) => INBOX.findIndex((m) => m.id === message.id);

  function handleDelete(message) {
    setMessages((list) => list.filter((m) => m.id !== message.id));
    setLastDeleted(message);
  }

  function handleUndo() {
    if (!lastDeleted) return;
    const restored = lastDeleted;
    setMessages((list) => [...list, restored].sort((a, b) => order(a) - order(b)));
    setLastDeleted(null);
  }

  return (
    <div className="stack">
      <ul className="inbox">
        {messages.map((message) => (
          <li key={message.id}>
            <div><strong>{message.from}</strong><span>{message.subject}</span></div>
            <button
              type="button"
              className="icon"
              aria-label={`Delete ${message.subject}`}
              onClick={() => handleDelete(message)}
            >
              <span aria-hidden="true">🗑</span>
            </button>
          </li>
        ))}
      </ul>
      {lastDeleted && (
        <div className="undo-row">
          <p className="status" role="status">Message deleted</p>
          <button type="button" onClick={handleUndo}>Undo</button>
        </div>
      )}
    </div>
  );
}
