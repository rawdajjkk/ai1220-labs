import { useState } from 'react';
import { SLOTS } from './data.js';

export default function PickupTime() {
  const [time, setTime] = useState('');
  const [confirmed, setConfirmed] = useState('');

  return (
    <div className="stack">
      <fieldset>
        <legend>Pickup time</legend>
        {SLOTS.map((slot) => {
          const full = slot.left <= 0;
          return (
            <label key={slot.time}>
              <input
                type="radio"
                name="pickup-time"
                value={slot.time}
                checked={time === slot.time}
                disabled={full}
                onChange={() => setTime(slot.time)}
              />
              {' '}{full ? `${slot.time}, full` : `${slot.time}, ${slot.left} left`}
            </label>
          );
        })}
      </fieldset>
      <button type="button" disabled={!time} onClick={() => setConfirmed(`Pickup at ${time}.`)}>
        Confirm pickup
      </button>
      <p className="result" role="status">{confirmed}</p>
    </div>
  );
}
