# Campus Workshop Board - Design notes

Name: Rawda Alkhoori  
Student ID: 25011159

## Diagram files

| View | Editable source (and page if needed) | Export |
|---|---|---|
| 01-context | `diagrams/source/01-context.mmd` | `diagrams/exports/01-context.png` |
| 02-containers | `diagrams/source/02-containers.mmd` | `diagrams/exports/02-containers.png` |
| 03-components | `diagrams/source/03-components.mmd` | `diagrams/exports/03-components.png` |
| 04-code | `diagrams/source/04-code.mmd` | `diagrams/exports/04-code.png` |
| 05-dynamic | `diagrams/source/05-dynamic.mmd` | `diagrams/exports/05-dynamic.png` |

## One structural choice (Exercise 2)

I chose a single Workshop Board API backed by one relational database because the pilot has only 200 students and one small development team; this keeps ownership, capacity and reservation invariants in one transaction boundary while remaining easy to deploy and maintain.

## Your components (Exercise 3)

| Name | Job | Customer rule(s) served |
|---|---|---|
| `IdentityGateway` | Verifies the university credential through Campus Identity and returns a trusted student ID, name and email. | R1, R4 |
| `WorkshopService` | Creates workshops, enforces valid fields, publishes only for the owner, and lists published workshop summaries. | R2, R3, R5 |
| `ReservationService` | Implements the reservation transaction, repeat-request behaviour, capacity checks, and organiser attendee visibility. | R3, R4, R5, R6 |
| `ConfirmationMailer` | Requests a confirmation from University Mail and reports unavailability without undoing a successful reservation. | R6 |
| `WorkshopRepository` | Reads and writes workshops and reservations in durable storage, including the unique reservation constraint. | R4, R5 |
| `AccessPolicy` | Applies owner-only publishing and organiser-only attendee-name/email visibility decisions. | R2, R3 |

## Reservation operation (Exercise 4)

`reserve(student: StudentIdentity, workshopId: WorkshopId) -> ReservationResult`, where `StudentIdentity` contains a verified student ID, name and email, and `workshopId` is a validated workshop identifier. Possible results are `CONFIRMED`, `EXISTING`, `FULL`, `UNVERIFIED`, or `NOT_FOUND`. The reservation component opens one database transaction, locks or atomically updates the workshop row, checks the unique `(workshopId, studentId)` reservation first, and then inserts only if `reservedCount < capacity`; the database unique constraint and atomic capacity check preserve the invariant under overlapping calls. On `CONFIRMED`, the seat is committed before requesting mail; if mail is unavailable, the student is told the reservation succeeded but email is unavailable. The complete operation and invariant are shown on `04-code`.

## Ari's incident (Exercise 5)

| Observation | Result |
|---|---|
| Stored state before | W17 is published with capacity 3 and 2 reservations (S21 and S22); no S23 reservation. Ari (S23) is signed in locally but the Campus Identity verification result is invalid. |
| Stored state after | Unchanged: W17 still has 2 reservations and no S23 reservation. No mail request is made. |
| Message Ari sees | `Reservation rejected: verify your university identity first.` |

The full message trace is shown in `diagrams/source/05-dynamic.mmd` and its export.
