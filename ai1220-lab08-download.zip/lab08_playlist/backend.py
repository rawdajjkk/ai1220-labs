"""Collaborative Playlist: the backend API and static page server.

    uv run python backend.py

The page and API share http://127.0.0.1:8000. API documentation is at /docs.
"""
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse

HERE = Path(__file__).resolve().parent


# The API uses the same JSON error shape for every rejected request.
def error_response(message: str, status_code: int) -> JSONResponse:
    return JSONResponse(status_code=status_code, content={"error": message})


def create_app() -> FastAPI:
    app = FastAPI(title="Collaborative Playlist")

    songs: list[dict[str, Any]] = [
        {"id": 1, "title": "Blue Monday", "artist": "New Order", "votes": 3},
        {"id": 2, "title": "Clocks", "artist": "Coldplay", "votes": 1},
        {"id": 3, "title": "Dancing Queen", "artist": "ABBA", "votes": 0},
    ]

    @app.get("/", include_in_schema=False)
    def page() -> FileResponse:
        return FileResponse(HERE / "index.html")

    @app.get("/songs")
    def get_songs() -> list[dict[str, Any]]:
        return songs

    @app.post("/songs", status_code=201)
    async def add_song(request: Request):
        try:
            body = await request.json()
        except (ValueError, UnicodeDecodeError):
            body = None

        if not isinstance(body, dict):
            return error_response("Please enter both a song title and an artist.", 400)

        title = body.get("title")
        artist = body.get("artist")
        if not isinstance(title, str) or not title.strip() or not isinstance(artist, str) or not artist.strip():
            return error_response("Please enter both a song title and an artist.", 400)

        song = {
            "id": max((item["id"] for item in songs), default=0) + 1,
            "title": title.strip(),
            "artist": artist.strip(),
            "votes": 0,
        }
        songs.append(song)
        return JSONResponse(status_code=201, content=song)

    @app.post("/songs/{song_id}/vote")
    def vote(song_id: int):
        for song in songs:
            if song["id"] == song_id:
                song["votes"] += 1
                return song
        return error_response(f"There is no song with id {song_id}.", 404)

    return app


app = create_app()

if __name__ == "__main__":
    print("Playlist: http://127.0.0.1:8000    API documentation: http://127.0.0.1:8000/docs", flush=True)
    uvicorn.run("backend:app", host="127.0.0.1", port=8000, reload=True)
